### 墨鱼自用Web网站
* 更新时间：2022-09-14
* 备份一些WebUrl
* 备注带★为QX网页优化对象

| 名称 | 影视网站 | 备注 |
| :----- | :----- | :----- |
| 真不卡 | https://www.ikandy.fun/ |  ★ |
| Libvio |   https://www.libvio.me/ |   新站，更新及时★ | 
| LeZhu |   http://www.lezhutv.com/ |   群友投稿，很不错★ | 
| 低端影视 |   http://ddys.tv | 影视老站，YYDS  | 
| 剧迷 |   https://gimytv.net/ | 影视，小而美★  |
| 厂长资源 |  https://www.qianoo.cn/ | 质量1080P★  | 
| 天空影视 |  https://www.tkys.tv/ | 新起之秀★  | 
| 大师兄 |  https://dsxys.com/ | 更新及时★  |
| Zzzfun | http://www.zzzfun.com/ |  在线动漫，比较全面 |
| Ebb | https://ebb.io/ | 在线动漫，可备用 |
| 独播库|  https://duboku.ru/ | 大同小异 |
| NO视频 | https://www.novipnoad.com/ | 种类会多些 |
| COKEMV | https://cokemv.me/ |  优质，体验蛮不错的★ |
| 哔嘀影视 | https://www.btbdys.com/ |  大名鼎鼎 |
| | | |
| **名称** | **资源下载** | **备注** |
| 片库 | https://www.pianku.la/ | 在线影视，具备磁力下载 |
| 磁力搜索|  https://xn--0tr952eyzisl5a.com/ | 猫和老鼠 |
| 动漫花园 |  https://share.dmhy.org/ | 动漫下载 |
| Nyaa |  https://nyaa.ink/ | 番剧著名站 |
| 音乐下载|  https://www.sq688.com/singer/10001.html | 自用无损音乐下载 |
| Z-library|  https://z-lib.org/ | 电子书下载，YYDS |
| Wallhaven |  https://wallhaven.cc/ |  自用壁纸下载 |
| 阿里小站   | https://newxiaozhan.com/t/video | 精心整理的阿里云盘资源 |
| 音范丝 | https://www.yinfans.me/ | 原盘下载 |
| | | |
| **名称** | **工具相关** | **备注** |
| Pixiv |  https://m.pixivic.com/dailyRank | 每日排行 |
| PDF处理|  https://smallpdf.com/ | 很全面 |
| 果核剥壳|  https://www.ghxi.com/ | Win软件下载 |
| 白描网页 |  https://web.baimiaoapp.com/ | 工具 |
| 图片放大 |  http://waifu2x.udp.jp/ |  waifu |
| | | |
| **名称** | **尽享阅读** | **备注** |
| 拷贝漫画 |  https://copymanga.com/ |  在线漫画，YYDS |
| 禁漫天堂|  https://18comic.org/ | 在线本子，18+韩漫★ |
| 书香门第|  http://www.txtnovel.top/ |  小说在线阅读，下载 |
| 知性教育 |  https://knowsex.net/ | 性教育 | 
| PicAcg |  https://cnpica.xyz/page/ios-tip-simplified.php | 著名本子，懂得都懂 |
| 奇漫屋 |  http://qiman56.com/ | 主流国漫 |
| 92韩漫 | http://92hm.top/ | 快把眼睛闭上 | 
| 肉漫 |  https://rouman5.com/ | 字如其名 |
| | | |
| **名称** | **好孩子看不见** | **备注** |
| Porn |  https://theporndude.com/ |  浏览过的，都说6 |
| 桃花族 | http://thzu.cc/ | 论坛 |
| Jable | https://jable.tv/ | 老司机说车开了 |
| Missav | https://missav.com/ | 中等偏上 |
| Netflav | https://netflav.com/ | AV界奈飞 |
| Hpjav | https://hpjav.tv/ | 还行，凑合 |

```diff
+ 通知频道： https://t.me/ddgksf2021
- 投稿助手： https://t.me/ddgksf2013_bot
```
